This is the Content Transfer Folder.
This folder and its contents will be available to all pipeline steps.